#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "conio2.h"
#include<iostream>

#define PLANSZA 24
#define POLE 6
#define POJEDYNCZEPOLE 2
#define SZEROKOSC 75

#define POLE_OFFSET 5
struct Slupek {
    int x;
    int y;
    bool pozycja[6] = { 0 };
};

struct Pionek {         // pionek 0-gracz 1,    1-gracz 2
    int x[15];          // 
    int y[15];
};

struct Gracz {
    int kostka;
    //int kostka[2] = { 0 };
    bool slupki[25] = { 0 };        // przypisanie do numeru pionka i jego lokalizacji 
    bool wybor[25] = { 0 };         // realna wartosc slupka
    bool dozajecia[25] = { 0 }; 
    int pionkiDom=0;                  
    int pionkiBar=0;
    int zaczyna = 0;
    int ruch=0;          // numer wykonanych ruch�w czy cos 
    int wynik=0;
};

struct Bar {
    int x;
    int y;
};

void wygladPlanszy(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void wyswietlPlansze(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void obramowaniePlanszy(char(*plansza)[SZEROKOSC]);
void wnetrzePlanszy(char(*plansza)[SZEROKOSC]);
void numeryGora(char(*plansza)[SZEROKOSC]);
void numeryGora2(char(*plansza)[SZEROKOSC]);
void numeryDol(char(*plansza)[SZEROKOSC]);
void Plansza(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void pierwszaCwiartka(char(*plansza)[SZEROKOSC], Slupek slupki[]);
void drugaCwiartka(char(*plansza)[SZEROKOSC]);
void trzeciaCwiartka(char(*plansza)[SZEROKOSC]);
void czwartaCwiartka(char(*plansza)[SZEROKOSC]);
void wypelnijPlansze(char(*plansza)[SZEROKOSC]);
void menu();
int kostka();
void inicjalizujSlupki( Slupek slupki[]); 
void rozpocznijGre(char(*plansza)[SZEROKOSC],  Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void Wstep(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[], Pionek pionek[]);
void rozmiescPiony(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[], Pionek pionek[]);
void wynik( Gracz gracz[]);
void rysujPionek(int numerSlupka, int miejsce, Slupek slupki[], Pionek pionek[], int i, int j);
void dodajZajete(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[],  Pionek pionek[]);
void Gra(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[],  Pionek pionek[]);
void kolorowaniePionow(int buff, int i, int j,  Pionek pionek[]);
int kolejka( Gracz gracz[], int kolej);
void UsuwaniePrzypisania(Slupek slupki[], Pionek pionek[], int numer, int kolej);
void petlaGry( Gracz gracz[],  Slupek slupki[], int kolej,int wynik,  Pionek pionek[]);
void wypisywanieDwuC(int i);
void zbijaniePlusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijanieMinusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijaniePlusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijanieMinusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void NowePrzypisanie(int numer, Slupek slupki[], Pionek pionek[],int kolej); 
void UsuwaniePrzypisaniaBar(Slupek slupki[], Pionek pionek[], int numer, int kolej, Bar barGracza[]);
void wyborPrzypisania(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]);

int main() {

    menu(); 

    return 0;
}

void menu() {
    char plansza[19][SZEROKOSC];    // do 70 jest koniec, pozniej napis home, plansza bedze znajdowala sie w X 1 do 70 i Y 0 do 18
    Slupek slupki[24];
    Pionek pionek[2];
    Gracz gracz[2];
    inicjalizujSlupki(slupki);
    wypelnijPlansze(&plansza[0]);

    wygladPlanszy(&plansza[0], slupki, gracz, pionek);
    settitle("Kacper Zuchowski nr194660");

    gotoxy(56, 7);
    cputs("Backgammon");

    gotoxy(55, 12);
    cputs("Start   -> 1");
    gotoxy(55, 13);
    cputs("Wczytaj -> 2");
    gotoxy(55, 14);
    cputs("Exit    -> 3");
    gotoxy(0, 0);
    int buff;
    buff = getch();


    // TO DO
    // tutaj trzeba zrobic p�tle, kt�ra by od�wie�a�a ekran - stan gry, ktory sie zmienia po kazdym ruchu

    switch (buff) {
    case '1':
        clrscr();
        gotoxy(1, 1);
        wyswietlPlansze(&plansza[0], slupki, gracz, pionek);
        break;
    case '2':
        clrscr();
        // wczytajStan();
        break;
    case '3':
        exit(0);
    default:
        break;
    }
}

void rozmiescPiony(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[], Pionek pionek[]) {

    int liczby[15];
    for (int j = 0; j <=1; j++) {
        for (int i = 0; i < 15; i++) {
            int numerSlupka, miejsce = 1;
            numerSlupka = rand() % 24 + 1;  // bazowo ustawione na pole 1
            if (j == 0) {
                liczby[i] = numerSlupka;
                gracz[0].slupki[numerSlupka] = true;    // numery 1 od 1
                rysujPionek(numerSlupka, miejsce, slupki, pionek, i, j);
            }
            else if (j == 1) {
                while (1) {
                    bool Znaleziony = false;  // Dodaj zmienn� logiczn� do �ledzenia obecno�ci numerSlupka

                    for (int k = 0; k < 15; k++) {
                        if (liczby[k] == numerSlupka) {
                            Znaleziony = true;  // Je�li numerSlupka jest znaleziony, ustaw zmienn� na true
                            break;
                        }
                    }
                    if (Znaleziony) {
                        numerSlupka = rand() % 24 + 1;
                    }
                    else {
                        gracz[1].slupki[numerSlupka] = true;
                        rysujPionek(numerSlupka, miejsce, slupki, pionek, i, j);
                        break;
                    }
                }
            }
        }
    }
    Gra(plansza, slupki, gracz, pionek);
}

void rysujPionek(int numerSlupka, int miejsce, Slupek slupki[], Pionek pionek[], int i, int j) {
    int buf = numerSlupka - 1, buf2 = miejsce - 1;
    if (slupki[buf].pozycja[buf2] == false) {
        slupki[buf].pozycja[buf2] = true;          // zaj�cie miejsca przez pion 
        
        pionek[j].x[i] = slupki[buf].x;
        pionek[j].y[i] = slupki[buf].y;
    }
    else{
        while (slupki[buf].pozycja[buf2] == true) {
            buf2 += 1;
        }
        slupki[buf].pozycja[buf2] = true;

        pionek[j].x[i] = slupki[buf].x;       // zawsze pokazuj� na 1 pole
        if (buf < 12) {
            pionek[j].y[i] = slupki[buf].y - buf2;  // dodanie w Y nast�pnych
        }
        else{
            pionek[j].y[i] = slupki[buf].y + buf2;  // odejmowanie od Y poniewa� bazowo jest na 1 polu
        }
    }
}

void Gra(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[],  Pionek pionek[]) {
    Bar barGracza[2];
    barGracza[0].x = 35;
    barGracza[0].y = 16;
    barGracza[1].x = 35;
    barGracza[1].y = 2;

    int kolej = 0;
    while (1) {
        gotoxy(1, 1);
        dodajZajete(plansza, slupki, gracz, pionek);    // samo uzupelnia przed rysowaniem planszy 
        for (int j = 0; j < 19; j++) {                // miejsca zaj�te przez piony
            for (int i = 0; i < SZEROKOSC; i++) {

                int buff = (int)plansza[j][i], k = 3;
                if (plansza[j][i] == (char)254) {
                    kolorowaniePionow(buff, i, j, pionek);
                }
                else {
                    textbackground(BLACK);
                    putch(buff);
                }
            }
            printf("\n");
        }
        gotoxy(82, 2);
        cputs("Wynik: ");
        wynik(gracz);
        gotoxy(82, 3);
        cputs("Baza:    1-6         19-24");
        gotoxy(82, 4);
        cputs("Kolej gracza ");
        kolej = kolejka(gracz, kolej);         // kolej ma realn� warto�� gracza 1/2 *doda� -1
        putch('0' + kolej);
        
        gotoxy(82, 5);
        int wynik = kostka();
        gotoxy(82, 6);
        cputs("Rzut 1 kostki: ");
        putch('0' + wynik);

        gotoxy(82, 5);
        clreol();
        int wynik2 = kostka();
        gotoxy(82, 7);
        cputs("Rzut 2 kostki: ");
        putch('0' + wynik2);

        gotoxy(82, 9);
        cputs("Wybierz pionka");

        gotoxy(82, 10);
        cputs("Dostepne pole:");      // wypisanie mo�liwych liczb 
        gotoxy(82, 11);
        cputs("( ");            
        for (int i = 0; i < 24; i++) {
            if (gracz[kolej - 1].slupki[i] == true) {
                wypisywanieDwuC(i);   
            }
        }
        cputs(")");
        gotoxy(85, 12);
        cputs("!-zacznij od 0 dla 1-cyfrowej-!");

        petlaGry(gracz, slupki, kolej, wynik, pionek);    // mechanika gry
        wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza);  // podmiana dla pionk�w, odpowiednio wywolac funkcje
        // przypisanie nowego, wybranego przez gracza miejsca
        
        // <-- jesli jest zbijany to pokaza� na bar 
        // dodac funkcje 
        // stworzyc nowa strukture
        Plansza(plansza, slupki, gracz, pionek);   // zresetowanie planszy 
        dodajZajete(plansza, slupki, gracz, pionek); // przypisanie nowych miejsc

        // zresetuj plansze 
        // te same bajery dla 2 kostki 
        petlaGry(gracz, slupki, kolej, wynik2, pionek);
        wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza);
        Plansza(plansza, slupki, gracz, pionek);   // zresetowanie planszy 
        dodajZajete(plansza, slupki, gracz, pionek);
        
        // POWINNO BYC GOTOWE 

        gotoxy(82, 17);
        cputs("idzie dobrze, wybierz 2 ruch");



        gotoxy(1, 22);
        cputs("Opcje: ");
        gotoxy(1, 23);
        cputs("Zapisz:(Z)  ");
        cputs("Cofnij:(C)  ");
        cputs("Wyjdz:(Q) ");

        int buff;
        buff = getch();

        switch (buff) {
        case 'z':
            // zapiszGre();
        case 'c':
            // cofnijRuch();
        case 'q':
            clrscr();
            menu();
        default:
            break;
        }
    }
}

void petlaGry( Gracz gracz[],  Slupek slupki[], int kolej,int wynik,  Pionek pionek[]) {

        gotoxy(82, 13);
        clreol();
        int numer, num2;
        numer = getch();
        num2 = getch();
        numer = (numer - '0') * 10 + (num2 - '0');

        if (gracz[kolej - 1].slupki[numer] == true) {
            UsuwaniePrzypisania(slupki, pionek, numer, kolej-1);    // gla gracza aktualnego wiec kolej -1 
                                                                    // w p�tli jest poprostu kolej
            clreol();
            gotoxy(82, 11);
            clreol();
            cputs("Wybrane pole: ");
            wypisywanieDwuC(numer);               // zosta� podany dobry, podaj ruch

            gotoxy(82, 13);
            clreol();
            cputs("Mozliwe ruchy: ");
            if (gracz[kolej - 1].slupki[numer + wynik] == true) {
                //  sprawdzamy czy dla obecnego gracza jest mo�liwosc do�o�y� pion
                gracz[kolej - 1].wybor[numer + wynik] = true;
                wypisywanieDwuC(numer + wynik);
                putch(' ');
            }
            if (gracz[kolej - 1].slupki[numer - wynik] == true) {
                gracz[kolej - 1].wybor[numer - wynik] = true;
                wypisywanieDwuC(numer - wynik);
                putch(' ');
            }
            // inny  gracz 
            if (kolej == 1) {
                if (gracz[kolej].slupki[numer + wynik] == true) {
                    //  sprawdzamy czy przeciwny gracz ma wiecej niz 1 pion
                    if (slupki[numer + wynik - 1].pozycja[1] == true) {     // 2 pozycja
                        gotoxy(81, 14);
                        clreol();
                        cputs("Wybierz inny (SPACJA)");
                        int buf = getch();
                        if (buf == ' ') {
                            petlaGry(gracz, slupki, kolej, wynik, pionek);
                        }
                        // chyba ewentualnie aby wr�ci�o
                    }
                    else {
                        gracz[kolej].dozajecia[numer + wynik];
                        zbijaniePlusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                    }
                }
                else if (gracz[kolej].slupki[numer + wynik] == false && (numer + wynik)<25 && gracz[kolej - 1].wybor[numer + wynik]!= true) { 
                    // slupek jest wolny 
                    zbijaniePlusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                }
                if (gracz[kolej].slupki[numer - wynik] == true) {
                    if (slupki[numer - wynik -1].pozycja[1] == true) {                        
                        gotoxy(81, 14);
                        clreol();
                        cputs("Wybierz inny (SPACJA)"); 
                        int buf = getch();
                        if (buf == ' ') {
                            petlaGry(gracz, slupki, kolej, wynik, pionek);
                        }
                    }
                    else {
                        gracz[kolej].dozajecia[numer - wynik];
                        zbijanieMinusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                    }
                }
                else if (gracz[kolej].slupki[numer - wynik] == false && (numer - wynik)>0 && gracz[kolej - 1].wybor[numer - wynik] != true) { // slupek jest wolny 
                    zbijanieMinusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                }
            }
            else if (kolej == 2) {
                if (gracz[kolej - 2].slupki[numer + wynik] == true) {
                    if (slupki[numer + wynik - 1].pozycja[1] == true) {
                        gotoxy(81, 14);
                        clreol();
                        cputs("Wybierz inny (SPACJA)");
                        int buf = getch();
                        if (buf == ' ') {
                            petlaGry(gracz, slupki, kolej, wynik, pionek);
                        }
                        // chyba ewentualnie aby wr�ci�o
                    }
                    else {
                        gracz[kolej-2].dozajecia[numer + wynik];
                        zbijaniePlusDwa(gracz,pionek, numer, wynik, slupki, kolej);
                    }
                }
                else if (gracz[kolej - 2].slupki[numer + wynik] == false && (numer + wynik) < 25 && gracz[kolej - 1].wybor[numer + wynik] != true) { // slupek jest 
                    zbijaniePlusDwa(gracz, pionek, numer, wynik, slupki, kolej);
                    
                }
                if (gracz[kolej - 2].slupki[numer - wynik] == true) {
                    if (slupki[numer - wynik - 1].pozycja[1] == true) {
                        
                        gotoxy(81, 14);
                        clreol();
                        cputs("Wybierz inny (SPACJA)");
                        int buf = getch();
                        if (buf == ' ') {
                            petlaGry(gracz, slupki, kolej, wynik, pionek);
                        }
                        else { return; }
                        // prze�lij do 2 kostki
                        // chyba ewentualnie aby wr�ci�o
                    }
                    else {
                        gracz[kolej-2].dozajecia[numer - wynik];
                        zbijanieMinusDwa(gracz, pionek, numer, wynik, slupki, kolej);
                    }
                }
                else if (gracz[kolej-2].slupki[numer - wynik] == false && (numer-wynik)>0 && gracz[kolej - 1].wybor[numer - wynik] != true) { // slupek jest wolny 
                    zbijanieMinusDwa(gracz, pionek, numer, wynik, slupki, kolej);
                }
            }

            // wybie� mozliwe miejsce
            // 
            // prze�o�enie koordynat�w pionka i usuni�cie aktualnych
            // powrot do gry

   // przypisanie nowych wsp�rz�dnych do pionlka o danym numerze
   //   i ponowne przypisanie nuemera pionka do wype�nienia planszy
   //   wywo�anie na nowo pustej planszy, aby j� wyczy�cic  -- Plansza(plansza);
   // przez dodajZajete(); -- nie trzeba bo funkcja gry (); sama to robi 

        }
        else {
            gotoxy(81, 14);
            clreol();
            cputs("Wybierz inny (SPACJA)");
            int buf = getch();
            if (buf == ' ') {
                petlaGry(gracz, slupki, kolej, wynik, pionek);
            }     // cofniecie do funkcji while
            // funkcja while
        }
        gotoxy(81, 15);
        clreol();
        cputs("Wybierz numer:");
        int buf = getch();

                            // funkcja do wyboru numeru 
        
}

void NowePrzypisanie(int numer, Slupek slupki[], Pionek pionek[], int kolej) {  // dla aktualnego gracza
    int buf2 = 0;
    while (slupki[numer - 1].pozycja[buf2] == true) {
        buf2 += 1;
    }
    slupki[numer].pozycja[buf2] = true;     // git
    int i;
    for (i = 0; i < 15; i++) {
        if (pionek[kolej - 1].x[i] == NULL) {
            break;
        }
        pionek[kolej - 1].x[i] = slupki[numer - 1].x;       // zawsze pokazuj� na 1 pole
        if (numer < 11) {   // numer nie jest pomiejszony o 1, wiec do 11
            pionek[kolej - 1].y[i] = slupki[numer - 1].y - buf2;
        }
        else {
            pionek[kolej - 1].y[i] = slupki[numer - 1].y + buf2;
        }
    }
}

void UsuwaniePrzypisania( Slupek slupki[], Pionek pionek[], int numer, int kolej){// gla gracza aktualnego wiec kolej -1 
                                                                    // w p�tli jest poprostu kolej dal innego przy def dac inny
    int buf2 = 0, k=kolej, n=numer;                                   
    while (slupki[n - 1].pozycja[buf2] == true) { 
        buf2 += 1;
    }
    slupki[n - 1].pozycja[buf2 - 1] = false;
    for (int i = 0; i < 15; i++) {
        if (n < 11) {
            if (pionek[k].y[i] == slupki[n - 1].y - buf2 && pionek[k].x[i] == slupki[n - 1].x) {
                pionek[k].y[i] = NULL;
                pionek[k].x[i] = NULL;
            }
        }
        else {
            if (pionek[k].y[i] == slupki[n - 1].y + buf2 && pionek[k].x[i] == slupki[n - 1].x) {
                pionek[k].y[i] = NULL;
                pionek[k].x[i] = NULL;
            }
        }
    }
}
void UsuwaniePrzypisaniaBar(Slupek slupki[], Pionek pionek[], int numer, int kolej, Bar barGracza[]) {// gla gracza aktualnego wiec kolej -1 
    // w p�tli jest poprostu kolej dal innego przy def dac inny
    int buf2 = 0, k = kolej, n = numer;
    while (slupki[n - 1].pozycja[buf2] == true) {
        buf2 += 1;
    }
    slupki[n - 1].pozycja[buf2 - 1] = false;
    for (int i = 0; i < 15; i++) {
        if (n < 11) {
            if (pionek[k].y[i] == slupki[n - 1].y - buf2 && pionek[k].x[i] == slupki[n - 1].x) {
                pionek[k].y[i] = barGracza[k].y;
                pionek[k].x[i] = barGracza[k].x;
                //pionek[kolej - 2].x[] = 35;
                //pionek[kolej-2].y[] = 16;
                // przypisac nowe kordynaty na bar i iterowa� wolne miejsca
            }
        }
        else {
            if (pionek[k].y[i] == slupki[n - 1].y + buf2 && pionek[k].x[i] == slupki[n - 1].x) {
                pionek[k].y[i] = barGracza[k].y;
                pionek[k].x[i] = barGracza[k].x;
            }
        }
    }
}
void zbijaniePlusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej){
    gracz[kolej - 1].wybor[numer + wynik] = true;
    gracz[kolej].wybor[numer + wynik] = false;
    wypisywanieDwuC(numer + wynik);
    putch(' ');
}
void zbijanieMinusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer - wynik] = true;
    gracz[kolej].wybor[numer - wynik] = false;
    wypisywanieDwuC(numer - wynik);
    putch(' ');
}
void zbijanieMinusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer - wynik] = true;
    gracz[kolej - 2].wybor[numer - wynik] = false;
    wypisywanieDwuC(numer - wynik);       // mechanika zbijania pionka
    putch(' ');
}
void zbijaniePlusDwa( Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer + wynik] = true;
    gracz[kolej - 2].wybor[numer + wynik] = false;
    wypisywanieDwuC(numer + wynik);       // mechanika zbijania pionka
    putch(' ');
}
void kolorowaniePionow(int buff, int i, int j, Pionek pionek[]) {
    for (int r = 0; r < 15; r++) {
        if (pionek[0].x[r] == i && pionek[0].y[r] == j) {       // pionek dla gracza 1 ma kolor niebieski
            textbackground(LIGHTBLUE);
            putch(buff);
            putch(buff);
            break;
        }
        else if (pionek[1].x[r] == i && pionek[1].y[r] == j) {      // pionek dla gracza 2 ma czerwony 
            textbackground(LIGHTRED);
            putch(buff);
            putch(buff);
            break;
        }
    }
}
void dodajZajete(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    for (int j = 0; j <= 1; j++) {
        for (int i = 0; i < 15; i++) {
            int x = pionek[j].x[i];
            int y = pionek[j].y[i];
            if (j == 0) {
                plansza[y][x] = (char)254;
                plansza[y][x + 1] = (char)254;
            }
            else {
                plansza[y][x] = (char)254;
                plansza[y][x + 1] = (char)254;
            }
        }
    }
}
void wyswietlPlansze(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    while (1) {
        gotoxy(0, 0);
        for (int j = 0; j < 19; j++) {
            for (int i = 0; i < SZEROKOSC; i++) {

                int buff = (int)plansza[j][i];
                putch(buff);
            }
            printf("\n");
        }

        gotoxy(1, 22);
        cputs("Opcje: ");
        gotoxy(1, 23);
        cputs("Rozpocznij:(R)  ");
        cputs("Zapisz:(Z)  ");
        cputs("Cofnij:(C)  ");
        cputs("Wyjdz:(Q) ");

        int buff;
        buff = getch();

        switch (buff) {
        case 'r':
            rozpocznijGre(plansza, slupki, gracz, pionek);

        case 'z':
            // zapiszGre();
        case 'c':
            // cofnijRuch();
        case 'q':
            clrscr();
            menu();
        default:
            break;
        }
    }
}
void rozpocznijGre(char(*plansza)[SZEROKOSC],  Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    int ilosc = 0, wynik=NULL;
    while (1) {
        gotoxy(82, 3);
        wynik = kostka();

        gotoxy(82, 4);
        cputs("Gracz 1");
        gotoxy(82, 5);
        cputs("Wartosc kostki: ");
        if (ilosc == 0) {
            putch('0' + wynik);
        }

        gotoxy(82, 6);
        cputs("Gracz 2");
        gotoxy(82, 7);
        cputs("Wartosc kostki: ");
        if (ilosc != 0) {
            putch('0' + wynik);
        }

        gracz[ilosc].kostka = wynik;
        ++ilosc;

        if (ilosc >= 2) {
            if (gracz[0].kostka == gracz[1].kostka) {
                gotoxy(82, 9);
                cputs("Remis, zacznij ponownie (SPACJA)");
                if (getch() == ' ')
                    for (int i = 0; i <= 6; i++) {
                        gotoxy(81, 4+i);
                        clreol();
                    }
                    rozpocznijGre(plansza, slupki, gracz, pionek);
            }
            else {
                gotoxy(82, 9);
                if (gracz[0].kostka > gracz[1].kostka) {
                    cputs("Zaczyna Gracz 1");
                    gracz[0].zaczyna = 1;
                    gotoxy(82, 10);
                    cputs("Kontynuj (SPACJA)");
                    if (getch() == ' ') Wstep(plansza, slupki, gracz, pionek);
                }
                else if (gracz[0].kostka < gracz[1].kostka) {
                    cputs("Zaczyna Gracz 2");
                    gracz[1].zaczyna = 1;
                    gotoxy(82, 10);
                    cputs("Kontynuj (SPACJA)");
                    if (getch() == ' ') Wstep(plansza, slupki, gracz, pionek);
                }
            }
        }
    }
    char buff;
    buff = getch();
    if (buff == 'q') {
        clrscr();
        menu();
    }
}
void Wstep(char(*plansza)[SZEROKOSC],  Slupek slupki[],  Gracz gracz[], Pionek pionek[]) {
    clrscr();
    while (1) {
        gotoxy(1, 1);
        for (int j = 0; j < 19; j++) {
            for (int i = 0; i < SZEROKOSC; i++) {
                int buff = (int)plansza[j][i];
                putch(buff);
            }
            printf("\n");
        }
        gotoxy(82, 2);
        cputs("Wynik: ");
        wynik(gracz);

        gotoxy(82, 4);
        cputs("Kolej gracza: ");
            if (gracz[0].zaczyna > gracz[1].zaczyna) {
                cputs("1");
            }
            else{
                cputs("2");
            }

        gotoxy(82, 6);
        cputs("Przydziel pionki:(P)  ");
        gotoxy(1, 22);
        cputs("Opcje: ");
        gotoxy(1, 23);
        cputs("Zapisz:(Z)  ");
        cputs("Cofnij:(B)  ");
        cputs("Wyjdz:(Q) ");

        int buff;
        buff = getch();

        switch (buff) {
        case 'p':
            // TO DO tutaj wszedzie przekazywac i aktualizowac slupki
            // //TO DO dorobic logike do rysujSlupki (wlasciwie to nie jest rysowanie, tylko ustawianie odpowiedniej wartosci na slupku pionkow

            clrscr();
            rozmiescPiony(plansza, slupki, gracz, pionek);
        case 'z':
            // zapiszGre();
        case 'b':
            // cofnijRuch();
        case 'q':
            clrscr();
            menu();
        default:
            break;
        }
    }
}
void wyborPrzypisania(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]) {
    int numer, num2;
    numer = getch();
    num2 = getch();
    numer = (numer - '0') * 10 + (num2 - '0');      // numer slupka (realny), nie od 0

    if (gracz[kolej - 1].wybor[numer] == true) {    // przyznanie nowego miejsca

        if (kolej - 1 == 1) {               // jesli jest zbijany to jego lokalizacja na NULL
            // przypisanie dla przeciwnego gracza +1 w BAR
            if (gracz[kolej - 2].dozajecia[numer] == true) {    // jesli jeest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej - 2, barGracza); // dla przeciwnego wiec -2
                gracz[kolej - 2].pionkiBar += 1;
            }
            else {
                NowePrzypisanie(numer, slupki, pionek, kolej);
            }
        }
        else if (kolej - 1 == 0) {
            if (gracz[kolej].dozajecia[numer] == true) {    // jesli jeest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej, barGracza); // dla przeciwnego wiec -0
            }
            else {
                NowePrzypisanie(numer, slupki, pionek, kolej);
            }
        }
    }
}
int kostka() {
    cputs("Nacisnij (G) aby wykonac rzut");
    srand(time(NULL));

    while (1) {
        char rzut;
        rzut = getch();
        if (rzut == 'g') {
            return rand() % 6 + 1;
        }
    }

}
int kolejka( Gracz gracz[], int kolej) {
    if (kolej == 0) {
        if (gracz[0].zaczyna == 1) { return 1; }
        else if(gracz[1].zaczyna == 1) { return 2; }
    }
    else if (kolej != 0) {
        if (kolej == 1) { return 2; }
        if (kolej == 2) { return 1; }
    }
}
void wynik( Gracz gracz[]) {
    cputs(" Gracz 1: ");
    textbackground(LIGHTBLUE);
    putch('0' + gracz[0].wynik);
    textbackground(BLACK);

    cputs("  Gracz 2: ");
    textbackground(LIGHTRED);
    putch('0' + gracz[1].wynik);
    textbackground(BLACK);
}
void wypisywanieDwuC(int i) {
    if (i < 10) { putch('0' + i); putch(' '); }
    if (i >= 10 && i < 20) {
        putch('0' + 1);
        putch('0' + i % 10);
        putch(' ');
    }
    if (i >= 20) {
        putch('0' + 2);
        putch('0' + i % 10);
        putch(' ');
    }
}
/* 

    do rysowania nowej planszy 


            for (int k = 0; k < POLE; k++) {
                if (slupki[i].pozycja[k]) {
                    int x = slupki[i].x;
                    int y = slupki[i].y;
                    plansza[11 + i][40 + slupki[i].pozycja[k] * POLE_OFFSET] = 'O';
                    plansza[11 + i][40 + slupki[i].pozycja[k] * POLE_OFFSET + 1] = 'O';
                }
            }


            for (int i = 0; i < 12; i++) {
        for (int k = 0; k < POLE; k++) {
            if (slupki[i].pozycja[k]) {
                int x = slupki[i].x;
                int y = slupki[i].y;
                plansza[2 + i][4 + x * POLE_OFFSET] = (char)254;
                plansza[2 + i][4 + x * POLE_OFFSET + 1] = (char)254;
            }
        }
    }
    for (int i = 12; i < 24; i++) {  // 2 g�rne, przypisane od 1 pola
        for (int k = 0; k < POLE; k++) {
            if (slupki[i].pozycja[k]) {
                int x = slupki[i].x;
                int y = slupki[i].y;
                plansza[11 + i][4 + slupki[i].pozycja[k] * POLE_OFFSET] = (char)254;
                plansza[11 + i][4 + slupki[i].pozycja[k] * POLE_OFFSET + 1] = (char)254; // rysuje pole obok
            }
        }
    }
*/
void wygladPlanszy(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    obramowaniePlanszy(&plansza[0]);
    wnetrzePlanszy(&plansza[0]);
    numeryGora(&plansza[0]);
    numeryGora2(&plansza[0]);
    numeryDol(&plansza[0]);
    Plansza(&plansza[0], slupki, gracz, pionek);
}

void inicjalizujSlupki(Slupek slupki[]) {
    int buff = 65;
    for (int i = 0; i < 12; i++) {  // 2 dolne, przypisane od 1 pola
        slupki[i].x = buff;
        slupki[i].y = 16;
        buff -= POLE_OFFSET;
        if (buff == 35) { buff = 29; }
    }
    int buff2 = 4;
    for (int i = 12; i < 24; i++) {  // 2 g�rne, przypisane od 1 pola 
        slupki[i].x = buff2;
        slupki[i].y = 2;
        buff2 += POLE_OFFSET;
        if (buff2 == 34) { buff2 = 40; }
    }
}
void wypelnijPlansze(char(*plansza)[SZEROKOSC]) {
    for (int j = 0; j < 19; j++) {
        for (int i = 0; i < SZEROKOSC; i++) {
            plansza[j][i] = ' ';
        }
    }
}
void obramowaniePlanszy(char(*plansza)[SZEROKOSC]) {  // x=0 niech bedzie pusty, aby plansza miala od 1 do 70
    for (int i = 1; i < 70; i++) {
        plansza[0][i] = ' ';
        plansza[1][i] = '=';
        for (int j = 2; j <= 16; j++) {
            plansza[j][i] = ' ';
        }
        plansza[17][i] = '=';
        plansza[18][i] = ' ';
    }
    for (int k = 2; k < 17; k++) {
        plansza[k][1] = ':';
        plansza[k][2] = ':';
        plansza[k][70 - 1] = ':';
        plansza[k][70 - 2] = ':';
        plansza[k][36] = '|';
        plansza[k][35] = '|';     //  70/2
        plansza[k][34] = '|';
    }
}

void wnetrzePlanszy(char(*plansza)[SZEROKOSC]) {
    plansza[1][70 / 2] = '0';
    plansza[17][70 / 2] = '0';

    plansza[9][70 / 2 - 2] = '[';
    plansza[9][70 / 2 - 1] = 'B';
    plansza[9][70 / 2] = 'A';
    plansza[9][70 / 2 + 1] = 'R';
    plansza[9][70 / 2 + 2] = ']';

    plansza[9][71] = 'H';
    plansza[9][72] = 'O';
    plansza[9][73] = 'M';
    plansza[9][74] = 'E';
}

void numeryGora(char(*plansza)[SZEROKOSC]) {
    plansza[0][4] = '1';
    plansza[0][5] = '3';
    plansza[0][9] = '1';
    plansza[0][10] = '4';
    plansza[0][14] = '1';
    plansza[0][15] = '5';
    plansza[0][19] = '1';
    plansza[0][20] = '6';
    plansza[0][24] = '1';
    plansza[0][25] = '7';
    plansza[0][29] = '1';
    plansza[0][30] = '8';
}

void numeryGora2(char(*plansza)[SZEROKOSC]) {
    plansza[0][40] = '1';
    plansza[0][41] = '9';
    plansza[0][45] = '2';
    plansza[0][46] = '0';
    plansza[0][50] = '2';
    plansza[0][51] = '1';
    plansza[0][55] = '2';
    plansza[0][56] = '2';
    plansza[0][60] = '2';
    plansza[0][61] = '3';
    plansza[0][65] = '2';
    plansza[0][66] = '4';
}
void numeryDol(char(*plansza)[SZEROKOSC]) {
    plansza[18][4] = '1';
    plansza[18][5] = '2';
    plansza[18][9] = '1';
    plansza[18][10] = '1';
    plansza[18][14] = '1';
    plansza[18][15] = '0';
    plansza[18][20] = '9';
    plansza[18][25] = '8';
    plansza[18][30] = '7';
    plansza[18][41] = '6';
    plansza[18][46] = '5';
    plansza[18][51] = '4';
    plansza[18][56] = '3';
    plansza[18][61] = '2';
    plansza[18][66] = '1';
}

void Plansza(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {         // WAZNE DO PRZEMYSLENIA

    // TO DO ta funkcja powinna byc aktualizowana stanem gry po kazdym ruchu
    // w tych funkcjach dodac obsluge rysowania punktow

    pierwszaCwiartka(&plansza[0], slupki);
    drugaCwiartka(&plansza[0]);
    trzeciaCwiartka(&plansza[0]);
    czwartaCwiartka(&plansza[0]);
}


void pierwszaCwiartka(char(*plansza)[SZEROKOSC], Slupek slupki[]) {

    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[11 + i][40] = '/';      //pole 6
            plansza[11 + i][41] = '\\';
            plansza[11 + i][45 + j] = ',';    // pole 5
            plansza[11 + i][50] = '/';      // pole 4
            plansza[11 + i][51] = '\\';
            plansza[11 + i][55 + j] = '.';    // pole 3
            plansza[11 + i][60] = '/';      //pole 2
            plansza[11 + i][61] = '\\';
            plansza[11 + i][65 + j] = ',';    //pole 1

            // TO DO
            // Przyk�adowa logika dla wrzucania nowego znaku w odpowiednim miejscu dla danego Pola - wrzucic w funkcje

        }
    }
}
void drugaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[11 + i][4] = '/';       //pole 12
            plansza[11 + i][5] = '\\';
            plansza[11 + i][9 + j] = ',';     //pole 11
            plansza[11 + i][14] = '/';      //pole 10
            plansza[11 + i][15] = '\\';
            plansza[11 + i][19 + j] = ',';    //pole 9
            plansza[11 + i][24] = '/';      //pole 8
            plansza[11 + i][25] = '\\';
            plansza[11 + i][29 + j] = ',';    //pole 7
        }
    }
}
void trzeciaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[2 + i][4 + j] = ',';      //pole 13
            plansza[2 + i][9] = '\\';       //pole 14
            plansza[2 + i][10] = '/';
            plansza[2 + i][14 + j] = ',';     //pole 15
            plansza[2 + i][19] = '\\';      //pole 16
            plansza[2 + i][20] = '/';
            plansza[2 + i][24 + j] = ',';     //pole 17
            plansza[2 + i][29] = '\\';      //pole 18
            plansza[2 + i][30] = '/';
        }
    }
}
void czwartaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[2 + i][40 + j] = ',';  //pole 19
            plansza[2 + i][45] = '\\';   //pole 20
            plansza[2 + i][46] = '/';
            plansza[2 + i][50 + j] = ',';  //pole 21
            plansza[2 + i][55] = '\\';   //pole 22
            plansza[2 + i][56] = '/';
            plansza[2 + i][60 + j] = ',';  //pole 23
            plansza[2 + i][65] = '\\';   //pole 24
            plansza[2 + i][66] = '/';
        }
    }
}