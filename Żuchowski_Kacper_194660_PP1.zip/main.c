#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "conio2.h"
#include <stdbool.h>

#define PLANSZA 24
#define POLE 6
#define POJEDYNCZEPOLE 2
#define SZEROKOSC 75
#define WYSOKOSC 19
#define POLE_OFFSET 5

struct Slupek {
    int x;
    int y;
    bool pozycja[6] = { 0 };
};

struct Pionek {         // pionek 0-gracz 1,    1-gracz 2
    int x[15];          // 
    int y[15];
};

struct Gracz {
    int kostka;
    bool slupki[25] = { 0 };        // przypisanie do numeru pionka i jego lokalizacji 
    bool wybor[25] = { 0 };         // realna wartosc slupka
    bool dozajecia[25] = { 0 };     // realna wartosc
    int pionkiDom = 0;
    int pionkiBar = 0;
    int zaczyna = 0;
    int wynik = 0;
};

struct Bar {
    int x;
    int y;
};

struct Dom {
    int x;
    int y;
};

void wygladPlanszy(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void wyswietlPlansze(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void obramowaniePlanszy(char(*plansza)[SZEROKOSC]);
void wnetrzePlanszy(char(*plansza)[SZEROKOSC]);
void numeryGora(char(*plansza)[SZEROKOSC]);
void numeryGora2(char(*plansza)[SZEROKOSC]);
void numeryDol(char(*plansza)[SZEROKOSC]);
void Plansza(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void pierwszaCwiartka(char(*plansza)[SZEROKOSC], Slupek slupki[]);
void drugaCwiartka(char(*plansza)[SZEROKOSC]);
void trzeciaCwiartka(char(*plansza)[SZEROKOSC]);
void czwartaCwiartka(char(*plansza)[SZEROKOSC]);
void wypelnijPlansze(char(*plansza)[SZEROKOSC]);
void menu();
int kostka();
void inicjalizujSlupki(Slupek slupki[]);
void rozpocznijGre(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void Wstep(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void rozmiescPiony(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void wynik(Gracz gracz[]);
void rysujPionek(int numerSlupka, int miejsce, Slupek slupki[], Pionek pionek[], int i, int j);
void dodajZajete(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void Gra(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);
void kolorowaniePionow(int buff, int i, int j, Pionek pionek[]);
int kolejka(Gracz gracz[], int kolej);
void UsuwaniePrzypisania(Slupek slupki[], Pionek pionek[], int numer, int kolej, Gracz gracz[]);
void petlaGry(Gracz gracz[], Slupek slupki[], int kolej, int wynik, Pionek pionek[], Bar barGracza[]);
void wypisywanieDwuC(int i);
int WpisanieII();
void zbijaniePlusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijanieMinusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijaniePlusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void zbijanieMinusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej);
void NowePrzypisanie(int numer, Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[]); // podawanie - dla odpowiedniego gracza w def
void UsuwaniePrzypisaniaBar(Slupek slupki[], Pionek pionek[], int numer, int kolej, Bar barGracza[], Gracz gracz[]);    // -||-
void wyborPrzypisania(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]); // bez odejmowania w kolej
void planszaGry(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]);    // z dodaniem pion�w
void dostPole(int kolej, Gracz gracz[], Slupek slupki[]);
void menuGry(Gracz gracz[], int kolej, int wynik, int wynik2, Slupek slupki[]);
bool WskazanieRuchu(Gracz gracz[], int  kolej, int numer, int wynik, bool spr, Pionek pionek[], Slupek slupki[]);
void DobrzePodanyNumer(Gracz gracz[], int kolej, Slupek slupki[], Pionek pionek[], int numer, int wynik, Bar barGracza[]);  // bez odejmowania w kolej
void domGraczaJeden(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]);
void domGraczaDwa(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]);
void petlaWewDom(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]);
void petlaWewDomII(Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[], int numer, Dom dom[]);
void wyborPrzypisaniaBar(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]);
void NowePrzypisanieBar(int numer, Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[], Bar barGracza[]);
void KoniecGry(char(*plansza)[SZEROKOSC], Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej);
void Ruch(char(*plansza)[SZEROKOSC], Gracz gracz[], int kolej, Slupek slupki[], int wynik, Pionek pionek[], Bar barGracza[], Dom dom[]);
void Akcja(char(*plansza)[SZEROKOSC], Gracz gracz[], int kolej, Slupek slupki[], int wynik, int wynik2, Pionek pionek[], Bar barGracza[], Dom dom[]);
void wczytaj(Slupek slupek[], Pionek pionek[], Gracz gracz[], char(*plansza)[SZEROKOSC]);
void zapis(Slupek slupek[], Pionek pionek[], Gracz gracz[]);

int main() {

    menu();

    return 0;
}

void menu() {
    char plansza[WYSOKOSC][SZEROKOSC];    // do 70 jest koniec, pozniej napis home, plansza bedze znajdowala sie w X 1 do 70 i Y 0 do 18
    Slupek slupki[24];
    Pionek pionek[2];
    Gracz gracz[2];
    inicjalizujSlupki(slupki);
    wypelnijPlansze(&plansza[0]);

    wygladPlanszy(&plansza[0], slupki, gracz, pionek);
    settitle("Kacper Zuchowski nr194660");

    gotoxy(56, 7);
    cputs("Backgammon");

    gotoxy(55, 12);
    cputs("Start   -> 1");
    gotoxy(55, 13);
    cputs("Wczytaj -> 2");
    gotoxy(55, 14);
    cputs("Exit    -> 3");
    gotoxy(0, 0);
    int buff;
    buff = getch();

    switch (buff) {
    case '1':
        clrscr();
        gotoxy(1, 1);
        wyswietlPlansze(&plansza[0], slupki, gracz, pionek);
        break;
    case '2':
        clrscr();
        wczytaj(slupki, pionek, gracz, plansza);
        break;
    case '3':
        exit(0);
    default:
        break;
    }
}

void zapis(Slupek slupek[], Pionek pionek[], Gracz gracz[]) {    // ZapisGry.txt  -- nazwa pliku  

    FILE* plik;
    plik = fopen("ZapisGry.txt", "w");     // otwieranie\tworzenie pliku, wcza�niej w+b

    int buf;
    if (plik != NULL) { //wystarczy if (fp)
        printf("Plik zosta� utworzony\n");
        system("pause");
        for (int k = 0; k < 24; k++) {      // ca�y slupek w jednej lini
            fprintf(plik, "Slupek %d: %d %d", k + 1, slupek[k].x, slupek[k].y);
            for (int i = 0; i < 6; i++) {
                if (slupek[k].pozycja[i]) { buf = slupek[k].pozycja[i]; }
                else { buf = slupek[k].pozycja[i]; }
                fprintf(plik, " %d", buf);
            }
            fprintf(plik, "\n");
        }
        for (int i = 0; i < 2; i++) {
            for (int k = 0; k < 15; k++) {
                fprintf(plik, "%d %d\n", pionek[i].x[k], pionek[i].y[k]);
            }
        }
        for (int i = 0; i < 2; i++) {
            fprintf(plik, "%d %d %d\n", gracz[i].wynik, gracz[i].pionkiDom, gracz[i].pionkiBar);
            for (int k = 1; k < 25; k++) {
                if (gracz[i].slupki[k]) { buf = gracz[i].slupki[k]; }
                else { buf = gracz[i].slupki[k]; }
                fprintf(plik, "%d ", buf);      // w jednej lini
            }
            fprintf(plik, "\n");
        }
        fclose(plik);
    }
    else {
        printf("B��d\n");
        exit(1);
    }
}
void wczytaj(Slupek slupek[], Pionek pionek[], Gracz gracz[], char(*plansza)[SZEROKOSC]) {
    FILE* plik;
    plik = fopen("ZapisGry.txt", "r");

    if (plik == NULL) {
        perror("B��d otwarcia pliku");
        exit(EXIT_FAILURE);
    }
    int buf;
    // Odczytaj ka�dy s�upek
    for (int k = 0; k < 24; k++) {      // ca�y slupek w jednej lini
        fscanf(plik, "Slupek %d: %d %d", &k + 1, &slupek[k].x, &slupek[k].y);
        for (int i = 0; i < 6; i++) {
            fscanf(plik, " %d", &buf);
            slupek[k].pozycja[i] = buf;
        }
        fprintf(plik, "\n");
    }
    for (int i = 0; i < 2; i++) {
        for (int k = 0; k < 15; k++) {
            fscanf(plik, "%d %d", &pionek[i].x[k], &pionek[i].y[k]);
            fprintf(plik, "\n");
        }
    }
    for (int i = 0; i < 2; i++) {
        fscanf(plik, "%d %d %d\n", &gracz[i].wynik, &gracz[i].pionkiDom, &gracz[i].pionkiBar);
        for (int k = 1; k < 25; k++) {
            fscanf(plik, "%d ", &buf);      // w jednej lini
            gracz[i].slupki[k] = buf;
        }
        fprintf(plik, "\n");
    }
    fclose(plik);
    Gra(plansza, slupek, gracz, pionek);
}
void rozmiescPiony(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {

    int liczby[15];
    for (int j = 0; j <= 1; j++) {
        for (int i = 0; i < 15; i++) {
            int numerSlupka, miejsce = 1;
            numerSlupka = rand() % 24 + 1;  // bazowo ustawione na pole 1
            if (j == 0) {
                liczby[i] = numerSlupka;
                gracz[0].slupki[numerSlupka] = true;    // numery 1 od 1
                rysujPionek(numerSlupka, miejsce, slupki, pionek, i, j);
            }
            else if (j == 1) {
                while (1) {
                    bool Znaleziony = false;  // Dodaj zmienn� logiczn� do �ledzenia obecno�ci numerSlupka

                    for (int k = 0; k < 15; k++) {
                        if (liczby[k] == numerSlupka) {
                            Znaleziony = true;  // Je�li numerSlupka jest znaleziony, ustaw zmienn� na true
                            break;
                        }
                    }
                    if (Znaleziony) {
                        numerSlupka = rand() % 24 + 1;
                    }
                    else {
                        gracz[1].slupki[numerSlupka] = true;
                        rysujPionek(numerSlupka, miejsce, slupki, pionek, i, j);
                        break;
                    }
                }
            }
        }
    }
    Gra(plansza, slupki, gracz, pionek);
}

void rysujPionek(int numerSlupka, int miejsce, Slupek slupki[], Pionek pionek[], int i, int j) {
    int buf = numerSlupka - 1, buf2 = miejsce - 1;
    if (slupki[buf].pozycja[buf2] == false) {
        slupki[buf].pozycja[buf2] = true;          // zaj�cie miejsca przez pion 

        pionek[j].x[i] = slupki[buf].x;
        pionek[j].y[i] = slupki[buf].y;
    }
    else {
        while (slupki[buf].pozycja[buf2] == true) {
            buf2 += 1;
        }
        slupki[buf].pozycja[buf2] = true;

        pionek[j].x[i] = slupki[buf].x;       // zawsze pokazuj� na 1 pole
        if (buf < 12) {
            pionek[j].y[i] = slupki[buf].y - buf2;  // dodanie w Y nast�pnych
        }
        else {
            pionek[j].y[i] = slupki[buf].y + buf2;  // odejmowanie od Y poniewa� bazowo jest na 1 polu
        }
    }
}
void menuGry(Gracz gracz[], int kolej, int wynik, int wynik2, Slupek slupki[]) {
    gotoxy(1, 22);
    cputs("Opcje: ");
    gotoxy(1, 23);
    cputs("Zapisz:(Z)  ");
    cputs("Wczytaj:(C)  ");
    cputs("Wyjdz:(Q) ");
    gotoxy(82, 9);
    cputs("Wybierz pionek:");

    dostPole(kolej, gracz, slupki); // wypisuje dostepne pola dla obecnego gracza, kolej jest -1 w 

    gotoxy(82, 13);
    clreol();
    cputs("Wybierz pole:");
}
void planszaGry(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    gotoxy(1, 1);
    dodajZajete(plansza, slupki, gracz, pionek);    // samo uzupelnia przed rysowaniem planszy 
    for (int j = 0; j < WYSOKOSC; j++) {                // miejsca zaj�te przez piony
        for (int i = 0; i < SZEROKOSC; i++) {

            int buff = (int)plansza[j][i], k = 3;
            if (plansza[j][i] == (char)254) {
                kolorowaniePionow(buff, i, j, pionek);
            }
            else {
                textbackground(BLACK);
                putch(buff);
            }
        }
        printf("\n");
    }
    gotoxy(82, 2);
    cputs("Wynik: ");
    wynik(gracz);
    gotoxy(82, 3);
    cputs("Baza:    1-6         19-24");
}

void Gra(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    
    Bar barGracza[2];
    barGracza[0].x = 35;
    barGracza[0].y = 16;
    barGracza[1].x = 35;
    barGracza[1].y = 2;
    Dom dom[2];
    dom[0].x = 72;
    dom[0].y = 10;
    dom[1].x = 72;
    dom[1].y = 8;

    int kolej = 0;
    while (1) {
        clrscr();
        planszaGry(plansza, slupki, gracz, pionek);
        gotoxy(82, 4);
        cputs("Kolej gracza ");
        kolej = kolejka(gracz, kolej);         // kolej ma realn� warto�� gracza 1/2 *doda� -1
        putch('0' + kolej);
        gotoxy(82, 5);
        int wynik = kostka();
        gotoxy(82, 6);
        cputs("Rzut 1 kostki: ");
        putch('0' + wynik);
        cputs(" <--");
        gotoxy(82, 5);
        clreol();
        int wynik2 = kostka();
        gotoxy(82, 7);
        cputs("Rzut 2 kostki: ");
        putch('0' + wynik2);
        menuGry(gracz, kolej, wynik, wynik2, slupki);
        
        if (wynik == wynik2) {
            Akcja(plansza, gracz, kolej, slupki, wynik, wynik2, pionek, barGracza, dom);
            gotoxy(82, 4);
            cputs("Kolej gracza ");
            putch('0' + kolej);

            gotoxy(82, 6);
            cputs("Rzut 1 kostki: ");
            putch('0' + wynik);
            cputs(" <--");

            gotoxy(82, 7);
            cputs("Rzut 2 kostki: ");
            putch('0' + wynik2);
        }
        Akcja(plansza, gracz, kolej, slupki, wynik,wynik2, pionek, barGracza, dom);
        
        // POWINNO BYC GOTOWE -- koniec petli
        KoniecGry(plansza, gracz, slupki, pionek, kolej);
        gotoxy(81, 17);
        cputs("Zakoncz ture (SPACJA) lub skorzystaj z opcji");
        // nowa funkcja opcje 
        switch (getch()) {
        case 'z':
            zapis(slupki, pionek,gracz);
            continue;
        case 'c':
            wczytaj(slupki, pionek, gracz, plansza);
        case 'q':
            clrscr();
            menu();
        default:
            continue;
        }
    }
}
void Akcja(char(*plansza)[SZEROKOSC], Gracz gracz[], int kolej, Slupek slupki[], int wynik,int wynik2, Pionek pionek[], Bar barGracza[], Dom dom[]) {
    Ruch(plansza, gracz, kolej, slupki, wynik, pionek, barGracza, dom); // pierwszy

    // druga kostka
    gotoxy(82, 4);
    cputs("Kolej gracza ");
    putch('0' + kolej);

    gotoxy(82, 6);
    clreol();
    cputs("Rzut 1 kostki: ");
    putch('0' + wynik);

    gotoxy(82, 7);
    cputs("Rzut 2 kostki: ");
    putch('0' + wynik2);
    cputs(" <--");
    menuGry(gracz, kolej, wynik, wynik2, slupki);

    Ruch(plansza, gracz, kolej, slupki, wynik2, pionek, barGracza, dom); // drugi
    menuGry(gracz, kolej, wynik, wynik2, slupki);
}
void Ruch(char(*plansza)[SZEROKOSC], Gracz gracz[], int kolej, Slupek slupki[], int wynik, Pionek pionek[], Bar barGracza[], Dom dom[]) {
    if (gracz[kolej - 1].pionkiBar != 0) {
        if (kolej == 2) {   // aktualnie 2 gracz

            gotoxy(82, 13);
            clreol();
            cputs("Mozliwe ruchy: ");   // baza d� 1-6   ZMIENIAM SLUPKI DLA GRACZA NA +1 Z ZAKRESEM 25
            bool spr = 0;
            if (gracz[kolej - 1].slupki[wynik] == true) {
                gracz[kolej - 1].wybor[wynik] = true;
                putch('0' + wynik);
                putch(' ');
                spr = 1;
            }   // sprawrzenie mo�liwo�ci ruchu o x kostki do przodu z 0
            else if (gracz[kolej - 2].slupki[wynik] == true) {
                if (slupki[wynik - 1].pozycja[1] != true) {    // zbijanie
                    gracz[kolej - 1].wybor[wynik] = true;
                    gracz[kolej - 2].dozajecia[wynik] = true;      // do przemy�lenia dla przeciwnego gracza.wyboru
                    putch('0' + wynik);
                    putch(' ');  // i=numer
                    spr = 1;
                }
            }
            else {
                gracz[kolej - 1].wybor[wynik] = true;
                putch('0' + wynik);
                putch(' ');
                spr = 1;
            }

            if (spr != 1) {
                return;// odes�anie do drugiego rzutu kostk� 
            }
            else {
                gotoxy(82, 18);
                clreol();
                cputs("Jest zbity, wybor: ");
                wyborPrzypisaniaBar(gracz, slupki, pionek, kolej, barGracza);
                wygladPlanszy(plansza, slupki, gracz, pionek);
            }


        }
        else {      // aktualnie 1 gracz
            gotoxy(82, 13);
            clreol();
            cputs("Mozliwe ruchy: ");   // Baza g�ra 19-24
            bool spr = 0;
            if (gracz[kolej - 1].slupki[25 - wynik] == true) {
                gracz[kolej - 1].wybor[25 - wynik] = true;
                wypisywanieDwuC(25 - wynik);
                putch(' ');
                spr = 1;
            }
            else if (gracz[kolej].slupki[25 - wynik] == true) {     // tutaj cos sie PIERDOLI
                if (slupki[24 - wynik].pozycja[1] != true) {    // zbijanie
                    gracz[kolej - 1].wybor[25 - wynik] = true;
                    gracz[kolej].dozajecia[25 - wynik] = true;
                    wypisywanieDwuC(25 - wynik);
                    putch(' ');
                    spr = 1;
                }
            }
            else {
                gracz[kolej - 1].wybor[25 - wynik] = true;
                wypisywanieDwuC(25 - wynik);
                putch(' ');
                spr = 1;
            }
            if (spr != 1) {
                return;// odes�anie do drugiego rzutu kostk� 
            }
            else {
                gotoxy(82, 18);
                clreol();
                cputs("Jest zbity, wybor: ");
                wyborPrzypisaniaBar(gracz, slupki, pionek, kolej, barGracza);
                wygladPlanszy(plansza, slupki, gracz, pionek);
                //plansza[barGracza[kolej - 1].y][35] = '|';
            }
        }
    }
    else {

        if (kolej == 2) {  // gracz 2 
            domGraczaDwa(gracz, slupki, kolej, dom, pionek, wynik, barGracza);
        }
        else {  // kolej==1, gracz 1
            domGraczaJeden(gracz, slupki, kolej, dom, pionek, wynik, barGracza);
        }

        petlaGry(gracz, slupki, kolej, wynik, pionek, barGracza);    // mechanika gry
        gotoxy(85, 14);
        cputs("Wybierz liczbe: ");
        wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza);
    }

    for (int e = 0; e < 26; e++) {  // zresetowanie wyboru i propozycji zaj�cia 
        gracz[0].wybor[e] = false;
        gracz[1].wybor[e] = false;
        gracz[0].dozajecia[e] = false;
        gracz[1].dozajecia[e] = false;
    }
    // zresetowanie planszy
    Plansza(plansza, slupki, gracz, pionek);
    clrscr();
    planszaGry(plansza, slupki, gracz, pionek);
}
void KoniecGry(char(*plansza)[SZEROKOSC], Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej) {
    if (gracz[kolej - 1].pionkiDom == 15) {
        gracz[kolej - 1].wynik += 1;
        if (kolej == 2) {   // aktualny drugi
            if (gracz[0].pionkiDom != 0) {
                gracz[kolej - 1].wynik += 1;
            }
            if (gracz[0].pionkiBar != 0) {
                gracz[kolej - 1].wynik += 1;
            }
        }
        else {
            if (gracz[1].pionkiDom != 0) {
                gracz[kolej - 1].wynik += 1;
            }
            if (gracz[1].pionkiBar != 0) {
                gracz[kolej - 1].wynik += 1;
            }
        }
        for (int i = 0; i < 2; i++) {
            gracz[i].pionkiDom = 0;
            gracz[i].pionkiBar = 0;
        }

        wyswietlPlansze(plansza, slupki, gracz, pionek); 
    }
}
void petlaGry(Gracz gracz[], Slupek slupki[], int kolej, int wynik, Pionek pionek[], Bar barGracza[]) {

    int numer = WpisanieII();

    if (gracz[kolej - 1].slupki[numer] == true) {
        DobrzePodanyNumer(gracz, kolej, slupki, pionek, numer, wynik, barGracza);
    }
    else {
        gotoxy(81, 15);
        clreol();
        cputs("Wybierz inny (SPACJA)");
        int buf = getch();
        if (buf == ' ') {
            petlaGry(gracz, slupki, kolej, wynik, pionek, barGracza);
        }     // cofniecie do funkcji while
    }
}
void wyborPrzypisania(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]) {

    int numer = WpisanieII();     // numer slupka (realny), nie od 0

    if (gracz[kolej - 1].wybor[numer] == true) {    // przyznanie nowego miejsca

        if (kolej == 2) {               // jesli jest zbijany to jego lokalizacja na NULL
            // przypisanie dla przeciwnego gracza +1 w BAR
            if (gracz[kolej - 2].dozajecia[numer] == true) {    // jesli jeest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej - 2, barGracza, gracz); // dla przeciwnego wiec -2
                NowePrzypisanie(numer, slupki, pionek, kolej - 1, gracz);
                gracz[kolej - 2].pionkiBar += 1;
            }
            else {
                NowePrzypisanie(numer, slupki, pionek, kolej - 1, gracz);
            }
        }
        else if (kolej == 1) {
            if (gracz[kolej].dozajecia[numer] == true) {    // jesli jest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej, barGracza, gracz); // dla przeciwnego wiec -0
                NowePrzypisanie(numer, slupki, pionek, kolej - 1, gracz);
                gracz[kolej].pionkiBar += 1;
            }
            else {
                NowePrzypisanie(numer, slupki, pionek, kolej - 1, gracz);
            }
        }
    }
    else {
        cputs("Podaj inny (SPACJA)");
        if (getch() == ' ') { wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza); }
    }
}

void NowePrzypisanie(int numer, Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[]) {  // dla aktualnego gracza
    int buf2 = 0, n = numer - 1, k = kolej;
    while (slupki[n].pozycja[buf2] != false) {
        buf2 += 1;
    }
    slupki[n].pozycja[buf2] = true;
    gracz[k].slupki[n + 1] = true;
    int i;
    for (i = 0; i < 15;) {
        if (pionek[k].x[i] == 0) {
            break;
        }
        i++;
    }
    pionek[k].x[i] = slupki[n].x;       // zawsze pokazuj� na 1 pole
    if (n < 12) {   // numer nie jest pomiejszony o 1, wiec do 11
        pionek[k].y[i] = slupki[n].y - buf2;        // k -1 !!!
    }
    else {
        pionek[k].y[i] = slupki[n].y + buf2;        // EWENTUALNIE BEZ + - 1 DLA PIONEK[].Y
    }

}
void wyborPrzypisaniaBar(Gracz gracz[], Slupek slupki[], Pionek pionek[], int kolej, Bar barGracza[]) {

    int numer = WpisanieII();     // numer slupka (realny), nie od 0

    if (gracz[kolej - 1].wybor[numer] == true) {    // przyznanie nowego miejsca
        if (kolej == 2) {               // jesli jest zbijany to jego lokalizacja na NULL
            // przypisanie dla przeciwnego gracza +1 w BAR
            if (gracz[kolej - 2].dozajecia[numer] == true) {    // jesli jeest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej - 2, barGracza, gracz); // dla przeciwnego wiec -2
                NowePrzypisanieBar(numer, slupki, pionek, kolej - 1, gracz, barGracza);
                gracz[kolej - 2].pionkiBar += 1;

            }
            else {
                NowePrzypisanieBar(numer, slupki, pionek, kolej - 1, gracz, barGracza);
            }
        }
        else if (kolej == 1) {
            if (gracz[kolej].dozajecia[numer] == true) {    // jesli jest zaj�ty 
                UsuwaniePrzypisaniaBar(slupki, pionek, numer, kolej, barGracza, gracz); // dla przeciwnego wiec -0
                NowePrzypisanieBar(numer, slupki, pionek, kolej - 1, gracz, barGracza);
                gracz[kolej].pionkiBar += 1;
            }
            else {
                NowePrzypisanieBar(numer, slupki, pionek, kolej - 1, gracz, barGracza);
            }
        }
    }
    else {
        cputs("Podaj inny (SPACJA)");
        if (getch() == ' ') { wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza); }
    }
    gracz[kolej - 1].pionkiBar -= 1;
}
void NowePrzypisanieBar(int numer, Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[], Bar barGracza[]) {  // dla aktualnego gracza
    int buf2 = 0, n = numer - 1, k = kolej;
    while (slupki[n].pozycja[buf2] == true) {
        buf2 += 1;
    }
    slupki[n].pozycja[buf2] = true;
    gracz[k].slupki[n + 1] = true;
    int i;
    for (i = 0; i < 15;) {
        if (pionek[k].x[i] == barGracza[k].x) {
            break;
        }
        i++;
    }
    pionek[k].x[i] = slupki[n].x;       // zawsze pokazuj� na 1 pole
    if (n < 12) {   // numer nie jest pomiejszony o 1, wiec do 11
        pionek[k].y[i] = slupki[n].y - buf2;        // k -1 !!!
    }
    else {
        pionek[k].y[i] = slupki[n].y + buf2;
    }
}
void NowePrzypisanieDom(int numer, Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[], Dom dom[]) {  // dla aktualnego gracza
    int buf2 = 0, k = kolej, n = numer - 1;  // numer bez -1, w def jest odjete                                
    while (slupki[n].pozycja[buf2] == true) {
        buf2 += 1;
    }
    slupki[n].pozycja[buf2 - 1] = false;
    if(buf2==1){
        gracz[k].slupki[n + 1] = false;
    }
    for (int i = 0; i < 15; i++) {
        if (n < 12) {
            if (pionek[k].y[i] == slupki[n].y - buf2 + 1 && pionek[k].x[i] == slupki[n].x) {    // dziala dol
                pionek[k].y[i] = dom[k].y;
                pionek[k].x[i] = dom[k].x;
            }
        }
        else {
            if (pionek[k].y[i] == slupki[n].y + buf2 - 1 && pionek[k].x[i] == slupki[n].x) {  // dziala gora
                pionek[k].y[i] = dom[k].y;
                pionek[k].x[i] = dom[k].x;
            }
        }
    }
}
void UsuwaniePrzypisania(Slupek slupki[], Pionek pionek[], int numer, int kolej, Gracz gracz[]) {// gla gracza aktualnego wiec kolej -1 
    // w p�tli jest poprostu kolej dal innego przy def dac inny
    int buf2 = 0, k = kolej, n = numer - 1;  // numer bez -1                                 
    while (slupki[n].pozycja[buf2] == true) {
        buf2 += 1;
    }
    slupki[n].pozycja[buf2 - 1] = false;
    if (buf2 == 1) {
        gracz[k].slupki[n + 1] = false;
    }
    for (int i = 0; i < 15; i++) {
        if (n < 12) {
            if (pionek[k].y[i] == slupki[n].y - buf2 + 1 && pionek[k].x[i] == slupki[n].x) {    // dziala dol
                pionek[k].y[i] = 0;
                pionek[k].x[i] = 0;
            }
        }
        else {
            if (pionek[k].y[i] == slupki[n].y + buf2 - 1 && pionek[k].x[i] == slupki[n].x) {  // dziala gora
                pionek[k].y[i] = 0;
                pionek[k].x[i] = 0;
            }
        }
    }
}
void UsuwaniePrzypisaniaBar(Slupek slupki[], Pionek pionek[], int numer, int kolej, Bar barGracza[], Gracz gracz[]) {// zbijanie i podsy�anie na bar
    // w p�tli jest poprostu kolej dala innego przy def r�n� wartosc -
    int buf2 = 0, k = kolej, n = numer - 1;
    int y = barGracza[k].y;
    int x = barGracza[k].x;
    while (slupki[n].pozycja[buf2] != false) {
        buf2 += 1;
    }
    slupki[n].pozycja[buf2 - 1] = false;
    if(buf2==1){
        gracz[k].slupki[n + 1] = false;
    }
    for (int i = 0; i < 15; i++) {
        if (n < 12) {
            if (pionek[k].y[i] == slupki[n].y - buf2 + 1 && pionek[k].x[i] == slupki[n].x) {
                pionek[k].y[i] = y;
                pionek[k].x[i] = x;
            }
        }
        else {
            if (pionek[k].y[i] == slupki[n].y + buf2 - 1 && pionek[k].x[i] == slupki[n].x) {
                pionek[k].y[i] = y;
                pionek[k].x[i] = x;
            }
        }
    }
}
void DobrzePodanyNumer(Gracz gracz[], int kolej, Slupek slupki[], Pionek pionek[], int numer, int wynik, Bar barGracza[]) {
    clreol();
    gotoxy(82, 11);
    clreol();
    cputs("Wybrane pole: ");
    wypisywanieDwuC(numer);               // zosta� podany dobry, podaj ruch

    gotoxy(82, 13);
    clreol();
    cputs("Mozliwe ruchy: ");

    bool spr = false;
    spr = WskazanieRuchu(gracz, kolej, numer, wynik, spr, pionek, slupki);

    if (spr == true) {
        UsuwaniePrzypisania(slupki, pionek, numer, kolej - 1, gracz);
        // w p�tli jest poprostu kolej wiec dla gracza aktualnego kolej -1 
    }
    else if (spr == false) {
        gotoxy(81, 15);
        clreol();
        cputs("Wybierz inny (SPACJA)");
        int buf = getch();
        if (buf == ' ') {
            petlaGry(gracz, slupki, kolej, wynik, pionek, barGracza);
        }
    }
}
bool WskazanieRuchu(Gracz gracz[], int kolej, int numer, int wynik, bool spr, Pionek pionek[], Slupek slupki[]) {
    if (gracz[kolej - 1].slupki[numer + wynik] == true) {
        //  sprawdzamy czy dla obecnego gracza jest mo�liwosc do�o�y� pion
        gracz[kolej - 1].wybor[numer + wynik] = true;
        wypisywanieDwuC(numer + wynik);
        putch(' ');
        spr = true;
    }
    if (gracz[kolej - 1].slupki[numer - wynik] == true) {
        gracz[kolej - 1].wybor[numer - wynik] = true;
        wypisywanieDwuC(numer - wynik);
        putch(' ');
        spr = true;
    }
    // inny  gracz 
    if (kolej == 1) {
        if (gracz[kolej].slupki[numer + wynik] == true) {
            //  sprawdzamy czy przeciwny gracz ma wiecej niz 1 pion
            if (slupki[numer + wynik - 1].pozycja[1] == false) {    // zbijanie
                zbijaniePlusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                spr = true;
            }
        }
        else if (gracz[kolej].slupki[numer + wynik] == false && (numer + wynik) < 25 && gracz[kolej - 1].wybor[numer + wynik] == false) {
            // slupek jest wolny 
            gracz[kolej - 1].wybor[numer + wynik] = true;
            wypisywanieDwuC(numer + wynik);
            putch(' ');
            spr = true;
        }
        if (gracz[kolej].slupki[numer - wynik] == true) {
            if (slupki[numer - wynik - 1].pozycja[1] == false) {
                zbijanieMinusJeden(gracz, pionek, numer, wynik, slupki, kolej);
                spr = true;
            }
        }
        else if (gracz[kolej].slupki[numer - wynik] == false && (numer - wynik) > 0 && gracz[kolej - 1].wybor[numer - wynik] == false) {
            // slupek jest wolny 
            gracz[kolej - 1].wybor[numer - wynik] = true;
            wypisywanieDwuC(numer - wynik);
            putch(' ');
            spr = true;
        }
    }
    else if (kolej == 2) {
        if (gracz[kolej - 2].slupki[numer + wynik] == true) {
            if (slupki[numer + wynik - 1].pozycja[1] == false) {
                zbijaniePlusDwa(gracz, pionek, numer, wynik, slupki, kolej);
                spr = true;
            }
        }
        else if (gracz[kolej - 2].slupki[numer + wynik] == false && (numer + wynik) < 25 && gracz[kolej - 1].wybor[numer + wynik] == false) { // slupek jest 
            // slupek jest wolny 
            gracz[kolej - 1].wybor[numer + wynik] = true;
            wypisywanieDwuC(numer + wynik);
            putch(' ');
            spr = true;

        }
        if (gracz[kolej - 2].slupki[numer - wynik] == true) {
            if (slupki[numer - wynik - 1].pozycja[1] == false) {
                zbijanieMinusDwa(gracz, pionek, numer, wynik, slupki, kolej);
                spr = true;
            }
        }
        else if (gracz[kolej - 2].slupki[numer - wynik] == false && (numer - wynik) > 0 && gracz[kolej - 1].wybor[numer - wynik] == false) { // slupek jest wolny 
            // slupek jest wolny 
            gracz[kolej - 1].wybor[numer - wynik] = true;
            wypisywanieDwuC(numer - wynik);
            putch(' ');
            spr = true;
        }
    }
    if (spr == true) { return true; }
    else { return false; }
}

void zbijaniePlusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer + wynik] = true;
    gracz[kolej].dozajecia[numer + wynik] = true;      // do przemy�lenia dla przeciwnego gracza.wyboru
    wypisywanieDwuC(numer + wynik);
    putch(' ');
}
void zbijanieMinusJeden(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer - wynik] = true;
    gracz[kolej].dozajecia[numer - wynik] = true;
    wypisywanieDwuC(numer - wynik);
    putch(' ');
}
void zbijanieMinusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer - wynik] = true;
    gracz[kolej - 2].dozajecia[numer - wynik] = true;
    wypisywanieDwuC(numer - wynik);       // mechanika zbijania pionka
    putch(' ');
}
void zbijaniePlusDwa(Gracz gracz[], Pionek pionek[], int numer, int wynik, Slupek slupki[], int kolej) {
    gracz[kolej - 1].wybor[numer + wynik] = true;
    gracz[kolej - 2].dozajecia[numer + wynik] = true;
    wypisywanieDwuC(numer + wynik);       // mechanika zbijania pionka
    putch(' ');
}
void kolorowaniePionow(int buff, int i, int j, Pionek pionek[]) {
    for (int r = 0; r < 15; r++) {
        if (pionek[0].x[r] == i && pionek[0].y[r] == j) {       // pionek dla gracza 1 ma kolor niebieski
            textbackground(LIGHTBLUE);
            putch(buff);
            putch(buff);
            break;
        }
        else if (pionek[1].x[r] == i && pionek[1].y[r] == j) {      // pionek dla gracza 2 ma czerwony 
            textbackground(LIGHTRED);
            putch(buff);
            putch(buff);
            break;
        }
    }
}
void domGraczaJeden(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]) {
    bool spr = 1;
    for (int i = 7; i < 25; i++) {  // czy wszystkie inne pola ma wolne 
        if (gracz[1].slupki[i] == true) {
            spr = 0;
        }
    }
    if (spr == 1) { // ma pionki tylko w bazie
        petlaWewDom(gracz, slupki, kolej, dom, pionek, wynik, barGracza);
    }
}
void domGraczaDwa(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]) {
    bool spr = 1;
    for (int i = 1; i < 19; i++) {  // czy wszystkie inne pola ma wolne 
        if (gracz[1].slupki[i] == true) {
            spr = 0;
        }
    }
    if (spr == 1) { // ma pionki tylko w bazie
        petlaWewDom(gracz, slupki, kolej, dom, pionek, wynik, barGracza);
    }
}
void petlaWewDom(Gracz gracz[], Slupek slupki[], int kolej, Dom dom[], Pionek pionek[], int wynik, Bar barGracza[]) {

    int numer = WpisanieII();

    if (gracz[kolej - 1].slupki[numer] == true) {
        if (numer + wynik > 24) {
            petlaWewDomII(slupki, pionek, kolej, gracz, numer, dom);
        }
        else {
            DobrzePodanyNumer(gracz, kolej, slupki, pionek, numer, wynik, barGracza);
            gotoxy(85, 14);
            cputs("Wybierz liczbe: ");
            wyborPrzypisania(gracz, slupki, pionek, kolej, barGracza);
        }
    }
    else {
        gotoxy(81, 15);
        clreol();
        cputs("Wybierz inny (SPACJA)");
        int buf = getch();
        if (buf == ' ') {
            petlaWewDom(gracz, slupki, kolej, dom, pionek, wynik, barGracza);
        }     
    }
}
void petlaWewDomII(Slupek slupki[], Pionek pionek[], int kolej, Gracz gracz[], int numer, Dom dom[]) {
    gotoxy(81, 13);
    clreol();
    cputs("Wprowadz pionek na pole HOME (SPACJA)");
    if (getch() == ' ') {
        UsuwaniePrzypisania(slupki, pionek, numer, kolej - 1, gracz);
        NowePrzypisanieDom(numer, slupki, pionek, kolej - 1, gracz, dom);
    }
    gracz[kolej - 1].pionkiDom += 1;
}
void dodajZajete(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    for (int j = 0; j <= 1; j++) {
        for (int i = 0; i < 15; i++) {
            int x = pionek[j].x[i];
            int y = pionek[j].y[i];
            if (j == 0) {
                plansza[y][x] = (char)254;
                plansza[y][x + 1] = (char)254;
            }
            else {
                plansza[y][x] = (char)254;
                plansza[y][x + 1] = (char)254;
            }
        }
    }
}
void wyswietlPlansze(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    while (1) {
        gotoxy(0, 0);
        for (int j = 0; j < WYSOKOSC; j++) {
            for (int i = 0; i < SZEROKOSC; i++) {

                int buff = (int)plansza[j][i];
                putch(buff);
            }
            printf("\n");
        }

        gotoxy(1, 22);
        cputs("Opcje: ");
        gotoxy(1, 23);
        cputs("Rozpocznij:(R)  ");
        cputs("Zapisz:(Z)  ");
        cputs("Cofnij:(C)  ");
        cputs("Wyjdz:(Q) ");

        int buff;
        buff = getch();

        switch (buff) {
        case 'r':
            rozpocznijGre(plansza, slupki, gracz, pionek);
        case 'z':
            zapis(slupki, pionek, gracz);
        case 'c':
            // cofnijRuch();
        case 'q':
            clrscr();
            menu();
        default:
            break;
        }
    }
}
void rozpocznijGre(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    int ilosc = 0, wynik = NULL;
    while (1) {
        gotoxy(82, 3);
        wynik = kostka();

        gotoxy(82, 4);
        cputs("Gracz 1");
        gotoxy(82, 5);
        cputs("Wartosc kostki: ");
        if (ilosc == 0) {
            putch('0' + wynik);
        }

        gotoxy(82, 6);
        cputs("Gracz 2");
        gotoxy(82, 7);
        cputs("Wartosc kostki: ");
        if (ilosc != 0) {
            putch('0' + wynik);
        }

        gracz[ilosc].kostka = wynik;
        ++ilosc;

        if (ilosc >= 2) {
            if (gracz[0].kostka == gracz[1].kostka) {
                gotoxy(82, 9);
                cputs("Remis, zacznij ponownie (SPACJA)");
                if (getch() == ' ')
                    for (int i = 0; i <= 6; i++) {
                        gotoxy(81, 4 + i);
                        clreol();
                    }
                rozpocznijGre(plansza, slupki, gracz, pionek);
            }
            else {
                gotoxy(82, 9);
                if (gracz[0].kostka > gracz[1].kostka) {
                    cputs("Zaczyna Gracz 1");
                    gracz[0].zaczyna = 1;
                    gotoxy(82, 10);
                    cputs("Kontynuj (SPACJA)");
                    if (getch() == ' ') Wstep(plansza, slupki, gracz, pionek);
                }
                else if (gracz[0].kostka < gracz[1].kostka) {
                    cputs("Zaczyna Gracz 2");
                    gracz[1].zaczyna = 1;
                    gotoxy(82, 10);
                    cputs("Kontynuj (SPACJA)");
                    if (getch() == ' ') Wstep(plansza, slupki, gracz, pionek);
                }
            }
        }
    }
    char buff;
    buff = getch();
    if (buff == 'q') {
        clrscr();
        menu();
    }
}
void Wstep(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    clrscr();
    while (1) {
        gotoxy(1, 1);
        for (int j = 0; j < WYSOKOSC; j++) {
            for (int i = 0; i < SZEROKOSC; i++) {
                int buff = (int)plansza[j][i];
                putch(buff);
            }
            printf("\n");
        }
        gotoxy(82, 2);
        cputs("Wynik: ");
        wynik(gracz);

        gotoxy(82, 4);
        cputs("Kolej gracza: ");
        if (gracz[0].zaczyna > gracz[1].zaczyna) {
            cputs("1");
        }
        else {
            cputs("2");
        }

        gotoxy(82, 6);
        cputs("Przydziel pionki:(P)  ");
        gotoxy(1, 22);
        cputs("Opcje: ");
        gotoxy(1, 23);
        cputs("Zapisz:(Z)  ");
        cputs("Wyjdz:(Q) ");

        int buff;
        buff = getch();

        switch (buff) {
        case 'p':
            rozmiescPiony(plansza, slupki, gracz, pionek);
        case 'z':
            // zapiszGre();
        case 'q':
            clrscr();
            menu();
        default:
            break;
        }
    }
}
int kostka() {
    cputs("Nacisnij (G) aby wykonac rzut");
    srand(time(NULL));

    while (1) {
        char rzut;
        rzut = getch();
        if (rzut == 'g') {
            return rand() % 6 + 1;
        }
    }
}
int kolejka(Gracz gracz[], int kolej) {
    if (kolej == 0) {
        if (gracz[0].zaczyna == 1) { return 1; }
        else if (gracz[1].zaczyna == 1) { return 2; }
    }
    else if (kolej != 0) {
        if (kolej == 1) { return 2; }
        if (kolej == 2) { return 1; }
    }
}
void wynik(Gracz gracz[]) {
    cputs(" Gracz 1: ");
    textbackground(LIGHTBLUE);
    putch('0' + gracz[0].wynik);
    textbackground(BLACK);

    cputs("  Gracz 2: ");
    textbackground(LIGHTRED);
    putch('0' + gracz[1].wynik);
    textbackground(BLACK);
}
void wypisywanieDwuC(int i) {
    if (i < 10) { putch('0' + i); putch(' '); }
    if (i >= 10 && i < 20) {
        putch('0' + 1);
        putch('0' + i % 10);
        putch(' ');
    }
    if (i >= 20) {
        putch('0' + 2);
        putch('0' + i % 10);
        putch(' ');

    }
}
void dostPole(int kolej, Gracz gracz[], Slupek slupki[]) {
    int k = kolej;
    gotoxy(82, 10);
    clreol();
    cputs("Dostepne pole:");      // wypisanie mo�liwych liczb 
    gotoxy(82, 11);
    clreol();
    cputs("( ");
    if (gracz[k - 1].pionkiBar == 0) {
        for (int i = 0; i <= 24; i++) {
            if (gracz[k - 1].slupki[i] == true) {
                wypisywanieDwuC(i);
            }
        }
        cputs(")");
    }
    else if (gracz[k - 1].pionkiBar == 1) {
        gotoxy(82, 11);
        clreol();
        cputs("Wyprowadz pionka z pola Bar");
    }
    else {
        gotoxy(82, 11);
        clreol();
        cputs("Wyprowadz pionki z pola Bar");
    }
    gotoxy(85, 12);
    clreol();
    cputs("!-zacznij od 0 dla 1-cyfrowej-!");
}
int WpisanieII() {
    int numer, num2;
    numer = getch();
    num2 = getch();
    numer = (numer - '0') * 10 + (num2 - '0');
    return numer;
}
void wygladPlanszy(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) {
    obramowaniePlanszy(&plansza[0]);
    wnetrzePlanszy(&plansza[0]);
    numeryGora(&plansza[0]);
    numeryGora2(&plansza[0]);
    numeryDol(&plansza[0]);
    Plansza(&plansza[0], slupki, gracz, pionek);
}
void inicjalizujSlupki(Slupek slupki[]) {
    int buff = 65;
    for (int i = 0; i < 12; i++) {  // 2 dolne, przypisane od 1 pola
        slupki[i].x = buff;
        slupki[i].y = 16;
        buff -= POLE_OFFSET;
        if (buff == 35) { buff = 29; }
    }
    int buff2 = 4;
    for (int i = 12; i < 24; i++) {  // 2 g�rne, przypisane od 1 pola 
        slupki[i].x = buff2;
        slupki[i].y = 2;
        buff2 += POLE_OFFSET;
        if (buff2 == 34) { buff2 = 40; }
    }
}
void wypelnijPlansze(char(*plansza)[SZEROKOSC]) {
    for (int j = 0; j < WYSOKOSC; j++) {
        for (int i = 0; i < SZEROKOSC; i++) {
            plansza[j][i] = ' ';
        }
    }
}
void obramowaniePlanszy(char(*plansza)[SZEROKOSC]) {  // x=0 niech bedzie pusty, aby plansza miala od 1 do 70
    for (int i = 1; i < 70; i++) {
        plansza[0][i] = ' ';
        plansza[1][i] = '=';
        for (int j = 2; j <= 16; j++) {
            plansza[j][i] = ' ';
        }
        plansza[17][i] = '=';
        plansza[18][i] = ' ';
    }
    for (int k = 2; k < 17; k++) {
        plansza[k][1] = ':';
        plansza[k][2] = ':';
        plansza[k][70 - 1] = ':';
        plansza[k][70 - 2] = ':';
        plansza[k][36] = '|';
        plansza[k][35] = '|';     //  70/2
        plansza[k][34] = '|';
    }
}
void wnetrzePlanszy(char(*plansza)[SZEROKOSC]) {
    plansza[1][70 / 2] = '0';
    plansza[17][70 / 2] = '0';

    plansza[9][70 / 2 - 2] = '[';
    plansza[9][70 / 2 - 1] = 'B';
    plansza[9][70 / 2] = 'A';
    plansza[9][70 / 2 + 1] = 'R';
    plansza[9][70 / 2 + 2] = ']';

    plansza[9][71] = 'H';
    plansza[9][72] = 'O';
    plansza[9][73] = 'M';
    plansza[9][74] = 'E';
}
void numeryGora(char(*plansza)[SZEROKOSC]) {
    plansza[0][4] = '1';
    plansza[0][5] = '3';
    plansza[0][9] = '1';
    plansza[0][10] = '4';
    plansza[0][14] = '1';
    plansza[0][15] = '5';
    plansza[0][19] = '1';
    plansza[0][20] = '6';
    plansza[0][24] = '1';
    plansza[0][25] = '7';
    plansza[0][29] = '1';
    plansza[0][30] = '8';
}
void numeryGora2(char(*plansza)[SZEROKOSC]) {
    plansza[0][40] = '1';
    plansza[0][41] = '9';
    plansza[0][45] = '2';
    plansza[0][46] = '0';
    plansza[0][50] = '2';
    plansza[0][51] = '1';
    plansza[0][55] = '2';
    plansza[0][56] = '2';
    plansza[0][60] = '2';
    plansza[0][61] = '3';
    plansza[0][65] = '2';
    plansza[0][66] = '4';
}
void numeryDol(char(*plansza)[SZEROKOSC]) {
    plansza[18][4] = '1';
    plansza[18][5] = '2';
    plansza[18][9] = '1';
    plansza[18][10] = '1';
    plansza[18][14] = '1';
    plansza[18][15] = '0';
    plansza[18][20] = '9';
    plansza[18][25] = '8';
    plansza[18][30] = '7';
    plansza[18][41] = '6';
    plansza[18][46] = '5';
    plansza[18][51] = '4';
    plansza[18][56] = '3';
    plansza[18][61] = '2';
    plansza[18][66] = '1';
}
void Plansza(char(*plansza)[SZEROKOSC], Slupek slupki[], Gracz gracz[], Pionek pionek[]) { 
    pierwszaCwiartka(&plansza[0], slupki);
    drugaCwiartka(&plansza[0]);
    trzeciaCwiartka(&plansza[0]);
    czwartaCwiartka(&plansza[0]);
}
void pierwszaCwiartka(char(*plansza)[SZEROKOSC], Slupek slupki[]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[11 + i][40] = '/';      //pole 6
            plansza[11 + i][41] = '\\';
            plansza[11 + i][45 + j] = ',';    // pole 5
            plansza[11 + i][50] = '/';      // pole 4
            plansza[11 + i][51] = '\\';
            plansza[11 + i][55 + j] = ',';    // pole 3
            plansza[11 + i][60] = '/';      //pole 2
            plansza[11 + i][61] = '\\';
            plansza[11 + i][65 + j] = ',';    //pole 1
        }
    }
}
void drugaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[11 + i][4] = '/';       //pole 12
            plansza[11 + i][5] = '\\';
            plansza[11 + i][9 + j] = ',';     //pole 11
            plansza[11 + i][14] = '/';      //pole 10
            plansza[11 + i][15] = '\\';
            plansza[11 + i][19 + j] = ',';    //pole 9
            plansza[11 + i][24] = '/';      //pole 8
            plansza[11 + i][25] = '\\';
            plansza[11 + i][29 + j] = ',';    //pole 7
        }
    }
}
void trzeciaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[2 + i][4 + j] = ',';      //pole 13
            plansza[2 + i][9] = '\\';       //pole 14
            plansza[2 + i][10] = '/';
            plansza[2 + i][14 + j] = ',';     //pole 15
            plansza[2 + i][19] = '\\';      //pole 16
            plansza[2 + i][20] = '/';
            plansza[2 + i][24 + j] = ',';     //pole 17
            plansza[2 + i][29] = '\\';      //pole 18
            plansza[2 + i][30] = '/';
        }
    }
}
void czwartaCwiartka(char(*plansza)[SZEROKOSC]) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= 1; j++) {
            plansza[2 + i][40 + j] = ',';  //pole 19
            plansza[2 + i][45] = '\\';   //pole 20
            plansza[2 + i][46] = '/';
            plansza[2 + i][50 + j] = ',';  //pole 21
            plansza[2 + i][55] = '\\';   //pole 22
            plansza[2 + i][56] = '/';
            plansza[2 + i][60 + j] = ',';  //pole 23
            plansza[2 + i][65] = '\\';   //pole 24
            plansza[2 + i][66] = '/';
        }
    }
}